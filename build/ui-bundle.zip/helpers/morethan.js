'use strict'

module.exports = (val, b) => val && Object.keys(val).length > b
