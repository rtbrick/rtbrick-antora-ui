'use strict'

module.exports = (val) => !val
