'use strict'

module.exports = (val) => val && Object.keys(val).length > 1
